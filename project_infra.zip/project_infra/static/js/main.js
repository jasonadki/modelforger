
// Data for System Architecture
var systemNodes = new vis.DataSet();
var systemEdges = new vis.DataSet();

// Data for Mission Architecture
var missionNodes = new vis.DataSet();
var missionEdges = new vis.DataSet();

// Current Data
var nodes = systemNodes;
var edges = systemEdges;
var currentArchitecture = 'System'; // 'System' or 'Mission'

var container = document.getElementById('network');
var data = {
    nodes: nodes,
    edges: edges
};
var options = {
    physics: false, // Turn off physics
    nodes: {
        shape: 'box',
        color: '#B19CD9',
        font: {
            color: '#000000'
        },
        fixed: {
            x: false,
            y: false
        },
        margin: 10
    },
    edges: {
        arrows: 'to'
    },
    interaction: {
        multiselect: true,
        selectConnectedEdges: false
    },
    manipulation: {
        enabled: false
    }
};
var network = new vis.Network(container, data, options);

// Variable to prevent recursive calls
var isUpdatingPositions = false;

